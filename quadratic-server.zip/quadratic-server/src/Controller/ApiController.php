<?php

namespace App\Controller;

use Cake\Core\Configure;
use Cake\Http\Exception\ForbiddenException;
use Cake\Http\Exception\NotFoundException;
use Cake\View\Exception\MissingTemplateException;

class ApiController extends AppController
{

  public function sendSuccess($message, $data){

    $response = [];
    $response['status'] = 1;
    $response['message'] = $message;
    $response['data'] = $data;

    $session = $this->getRequest()->getSession();
    $session->write('response_data', $response);

    echo  json_encode($response);
    die;
  }

  public function sendError($message, $data = NULL){

    $response = [];
    $response['status'] = 0;
    $response['message'] = $message;

    $session = $this->getRequest()->getSession();
    $session->write('response_data', $response);


    echo  json_encode($response);
    die;
  }


}
