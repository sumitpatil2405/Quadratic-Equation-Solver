<?php

namespace App\Controller;

use Cake\Core\Configure;
use Cake\Http\Exception\ForbiddenException;
use Cake\Http\Exception\NotFoundException;
use Cake\View\Exception\MissingTemplateException;
use Cake\ORM\TableRegistry;


class EquationController extends ApiController
{

    public function initialize()
    {
        parent::initialize();
        $this->loadComponent('RequestHandler');
    }

    /**
     * Displays a view
     *
     * @param array ...$path Path segments.
     * @return \Cake\Http\Response|null
     * @throws \Cake\Http\Exception\ForbiddenException When a directory traversal attempt.
     * @throws \Cake\Http\Exception\NotFoundException When the view file could not
     *   be found or \Cake\View\Exception\MissingTemplateException in debug mode.
     */
     public function getSolution(){
       $this->autoRender = false;
       $status = 0;
       $message = '';
       $data = [];

       if ($this->request->is('post')) {
           $request_data = $this->request->data;

           $a = $this->request->data['a'];
           $b = $this->request->data['b'];
           $c = $this->request->data['c'];
           $token = $this->request->data['token'];

          // validate isset or not
          if(!isset($a)){
             $message = 'Please provide input a.';
             $this->sendError($message);
           }
           if(!isset($b)){
             $message = 'Please provide input b.';
             $this->sendError($message);
           }
           if(!isset($c)){
             $message = 'Please provide input c.';
             $this->sendError($message);
           }

          // validate numeric
          if(!is_numeric($a)){
             $message = 'Please enter numeric value for input a.';
             $this->sendError($message);
           }
           if(!is_numeric($b)){
             $message = 'Please enter numeric value for input b.';
             $this->sendError($message);
           }
           if(!is_numeric($c)){
             $message = 'Please enter numeric value for input c.';
             $this->sendError($message);
           }

          // validate greater then 0
          if($a < 0){
            $message = 'Please enter value greater then zero for input a.';
            $this->sendError($message);
          }

          if($b < 0){
            $message = 'Please enter value greater then zero for input b.';
            $this->sendError($message);
          }

          if($c < 0){
            $message = 'Please enter value greater then zero for input c.';
            $this->sendError($message);
          }

          // validate non empty
          if(!isset($token)){
            $message = 'Please provide token.';
            $this->sendError($message);
          }

          // validate token
          if($token !== sha1($a . $b . $c)){
            $message = 'Token mismatch.';
            $this->sendError($message);
          }

       }
       $return_result = $this->getResult($a, $b, $c);




       if($return_result['status'] != 0){
         $message = $return_result['message'];
         $data = $return_result['result'];

         $apiLogTable = TableRegistry::get('ApiLogs');
         $apiLog = $apiLogTable->newEntity();

         $apiLog->input_a = $a;
         $apiLog->input_b = $b;
         $apiLog->input_c = $c;
         $apiLog->output_x = isset($data['x']) ? $data['x'] : '';
         $apiLog->output_x1 = isset($data['x1']) ? $data['x1'] : '';
         $apiLog->output_x2 = isset($data['x2']) ? $data['x2'] : '';
         $apiLog->output_message = isset($message) ? $message : '';
         $apiLogTable->save($apiLog);

      
         $this->sendSuccess($message, $data);
      } else {
        $message = $return_result['message'];
        $this->sendError($message);
      }

     }

     public function getResult($a, $b, $c){
       $status = 0;
       $message = '';
       $result = [];
       $d = ($b*$b) - (4*$a*$c);

       if($d < 0) { // no solution
          $status = 0;
            $message =  "No real solutions found.";
       } elseif($d == 0) { // only one solution
            $status = 1;
            $message =  "One solution found.";
            $result['x'] = (float) -$b / 2.0 / $a;
       } elseif ($d > 0) { // two solutions
            $status = 2;
            $x1 =  (float) (-$b + sqrt($d)) / 2.0 / $a;
            $x2 =  (float) (-$b - sqrt($d)) / 2.0 / $a;

            if($x1){
              $result['x1'] = (float) number_format($x1, 5, '.', '');
            } else {
              $result['x1'] = $x1;
            }

            if($x2){
              $result['x2'] = (float) number_format($x2, 5, '.', '');
            } else {
              $result['x2'] = $x2;
            }

            $message =  "Two solutions found.";
       } else { // two solutions
             $status = 2;
             $x1 = (float) -$b / 2.0 / $a. ", " . sqrt(-$d) / 2.0 / $a;
             $x2 =  (float)-$b / 2.0 / $a. ", ". -sqrt(-$d) / 2.0 / $a;
             
             if($x1){
                $result['x1'] = (float) number_format($x1, 5, '.', '');
              } else {
                $result['x1'] = $x1;
              }

              if($x2){
                $result['x2'] = (float) number_format($x2, 5, '.', '');
              } else {
                $result['x2'] = $x2;
              }

             $message =  "Two solutions found.";
       }

       $result_data['message'] = $message;
       $result_data['result'] = $result;
       $result_data['status'] = $status;

       return $result_data;
     }

}
