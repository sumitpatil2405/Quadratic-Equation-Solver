<?php
namespace App\Controller;

use App\Controller\AppController;


class ApiLogsController extends AppController
{

    public function index()
    {
        $apiLogs = $this->paginate($this->ApiLogs);

        $this->set(compact('apiLogs'));
    }

    /**
     * View method
     *
     * @param string|null $id Api Log id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $apiLog = $this->ApiLogs->get($id, [
            'contain' => []
        ]);

        $this->set('apiLog', $apiLog);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $apiLog = $this->ApiLogs->newEntity();
        if ($this->request->is('post')) {
            $apiLog = $this->ApiLogs->patchEntity($apiLog, $this->request->getData());
            if ($this->ApiLogs->save($apiLog)) {
                $this->Flash->success(__('The api log has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The api log could not be saved. Please, try again.'));
        }
        $this->set(compact('apiLog'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Api Log id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $apiLog = $this->ApiLogs->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $apiLog = $this->ApiLogs->patchEntity($apiLog, $this->request->getData());
            if ($this->ApiLogs->save($apiLog)) {
                $this->Flash->success(__('The api log has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The api log could not be saved. Please, try again.'));
        }
        $this->set(compact('apiLog'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Api Log id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $apiLog = $this->ApiLogs->get($id);
        if ($this->ApiLogs->delete($apiLog)) {
            $this->Flash->success(__('The api log has been deleted.'));
        } else {
            $this->Flash->error(__('The api log could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
