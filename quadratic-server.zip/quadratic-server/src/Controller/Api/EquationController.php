<?php

namespace App\Controller\api;

use Cake\Core\Configure;
use Cake\Http\Exception\ForbiddenException;
use Cake\Http\Exception\NotFoundException;
use Cake\View\Exception\MissingTemplateException;


class EquationController extends ApiController
{

    public function initialize()
    {
        parent::initialize();
        $this->loadComponent('RequestHandler');
    }
   
  public function getSolution(){
    $this->autoRender = false;
    $status = 0;
    $message = '';
    $data = [];

    if ($this->request->is('post')) {
        $request_data = $this->request->data;

        if(!isset($request_data['a'])){
          $message = 'Please provide a input';
          $this->sendError($message);
        }
        if(!isset($request_data['b'])){

        }
        if(!isset($request_data['c'])){

        }
        if(!isset($request_data['token'])){

        }
        if(!isset($request_data['token'])){

        }
    }

  }


}
