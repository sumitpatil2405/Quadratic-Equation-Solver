<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * ApiLogs Model
 *
 * @method \App\Model\Entity\ApiLog get($primaryKey, $options = [])
 * @method \App\Model\Entity\ApiLog newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\ApiLog[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\ApiLog|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\ApiLog|bool saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\ApiLog patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\ApiLog[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\ApiLog findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class ApiLogsTable extends Table
{

  
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('api_logs');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');
    }

    
    public function validationDefault(Validator $validator)
    {
        $validator
            ->nonNegativeInteger('id')
            ->allowEmpty('id', 'create');

        $validator
            ->scalar('input_a')
            ->maxLength('input_a', 12)
            ->allowEmpty('input_a');

        $validator
            ->scalar('input_b')
            ->maxLength('input_b', 12)
            ->allowEmpty('input_b');

        $validator
            ->scalar('input_c')
            ->maxLength('input_c', 12)
            ->allowEmpty('input_c');

        $validator
            ->scalar('output_x')
            ->maxLength('output_x', 12)
            ->allowEmpty('output_x');

        $validator
            ->scalar('output_x1')
            ->maxLength('output_x1', 12)
            ->allowEmpty('output_x1');

        $validator
            ->scalar('output_x2')
            ->maxLength('output_x2', 12)
            ->allowEmpty('output_x2');

        $validator
            ->scalar('output_message')
            ->maxLength('output_message', 100)
            ->allowEmpty('output_message');

        return $validator;
    }
}
