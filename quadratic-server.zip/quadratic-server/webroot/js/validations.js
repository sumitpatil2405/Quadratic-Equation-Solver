function checkEmptyAndNumeric(ele){
  var elem = jQuery(ele);
  var element_val = jQuery(ele).val();
  var form_group = jQuery(ele).closest('.form-group');
  var contents = jQuery(ele).attr('id');
  var has_error = 1;
  if(contents == "a" && element_val == 0){
    form_group.addClass('error');
    form_group.find('.error_msg').remove();
    form_group.append('<span class="error_msg">input value for "a" can not be zero</span>');
  }
  else if(element_val == ''){
    form_group.addClass('error');
    form_group.find('.error_msg').remove();
    form_group.append('<span class="error_msg">Empty input</span>');
  }
  else if(isNaN(element_val)){
    form_group.addClass('error');
    form_group.find('.error_msg').remove();
    form_group.append('<span class="error_msg">Please enter numeric value only.</span>');
  }
  else if(element_val < 0){
    form_group.addClass('error');
    form_group.find('.error_msg').remove();
    form_group.append('<span class="error_msg">Please enter value greater then zero.</span>');
  } else {
    form_group.removeClass('error');
    form_group.find('.error_msg').remove();
    has_error = 0;
  }

  return has_error;
}
