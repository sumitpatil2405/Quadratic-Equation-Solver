<?php
/**
 * CakePHP(tm) : Rapid Development Framework (https://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 * @link      https://cakephp.org CakePHP(tm) Project
 * @since     0.2.9
 * @license   https://opensource.org/licenses/mit-license.php MIT License
 */
namespace App\Controller;

use Cake\Core\Configure;
use Cake\Http\Exception\ForbiddenException;
use Cake\Http\Exception\NotFoundException;
use Cake\View\Exception\MissingTemplateException;
use Cake\ORM\TableRegistry;
/**
 * Static content controller
 *
 * This controller will render views from Template/Pages/
 *
 * @link https://book.cakephp.org/3.0/en/controllers/pages-controller.html
 */
class PagesController extends AppController
{

    /**
     * Displays a view
     *
     * @param array ...$path Path segments.
     * @return \Cake\Http\Response|null
     * @throws \Cake\Http\Exception\ForbiddenException When a directory traversal attempt.
     * @throws \Cake\Http\Exception\NotFoundException When the view file could not
     *   be found or \Cake\View\Exception\MissingTemplateException in debug mode.
     */
    public function display(...$path)
    {
        // $count = count($path);
        // if (!$count) {
        //     return $this->redirect('/');
        // }
        // if (in_array('..', $path, true) || in_array('.', $path, true)) {
        //     throw new ForbiddenException();
        // }
        // $page = $subpage = null;

        // if (!empty($path[0])) {
        //     $page = $path[0];
        // }
        // if (!empty($path[1])) {
        //     $subpage = $path[1];
        // }
        // $this->set(compact('page', 'subpage'));

        try {
            $this->render(implode('/', $path));
        } catch (MissingTemplateException $exception) {
            if (Configure::read('debug')) {
                throw $exception;
            }
            throw new NotFoundException();
        }
    }

    public function qesolver()
    {
        $a = $this->request->getQuery('a');
        $b = $this->request->getQuery('b');
        $c = $this->request->getQuery('c');
        $token = $this->request->getQuery('token');

        $sha1_str = sha1($a.$b.$c);

        $result = array();
        if($sha1_str == $token) {
            $logs = TableRegistry::get('math_log');

            // Start a new query.
            $query = $logs->query();
            $query->insert(['a', 'b', 'c', 'token', 'timestamp'])
            ->values([
                'a' => $a,
                'b' => $b,
                'c' => $c,
                'token' => $token,
                'timestamp' => date("Y-m-d h:i:sa")
            ])
            ->execute();

            if($a == 0) {
                $result['status'] = -1;
                $result['message'] = "a can not be 0.";
            } else {
                if($b * $b - 4 * $a * $c < 0) {
                    $result['status'] = 0;
                    $result['message'] = "No Solution";
                } else if($b * $b - 4 * $a * $c == 0) {
                    $result['status'] = 1;
                    $result['message'] = "Single Solution";
                    $result['x1'] = -$b / (2 * $a);
                } else {
                    $result['status'] = 2;
                    $result['message'] = "Two Solution";
                    $sq = sqrt($b * $b - 4 * $a * $c);
                    $result['x1'] = (-$b + $sq) / (2 * $a);
                    $result['x2'] = (-$b - $sq) / (2 * $a);
                }
            }
        } else {
            $result['status'] = -1;
            $result['message'] = "Error";
        }

        $resultJ = json_encode($result);
        $this->response->type('json');
        $this->response->body($resultJ);
        return $this->response;
    }

    public function getToken()
    {
        $tokenStr = $this->request->getQuery('tokenStr');
        $sha1_str = sha1($tokenStr);
        $resultJ = json_encode(array('result' => array('token' => $sha1_str)));
        $this->response->type('json');
        $this->response->body($resultJ);
        return $this->response;
        
    }
}
